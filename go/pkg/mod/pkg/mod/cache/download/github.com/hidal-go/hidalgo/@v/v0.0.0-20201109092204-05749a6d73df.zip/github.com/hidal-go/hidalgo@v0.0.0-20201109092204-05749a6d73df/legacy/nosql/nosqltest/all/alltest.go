package alltest

import (
	_ "github.com/hidal-go/hidalgo/legacy/nosql/couch/test"
	_ "github.com/hidal-go/hidalgo/legacy/nosql/elastic/test"
	_ "github.com/hidal-go/hidalgo/legacy/nosql/mongo/test"
)
