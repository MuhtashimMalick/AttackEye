// Package hidalgo provides high-level database abstractions over existing databases.
//
// See subpackages for more information.
package hidalgo

//go:generate dot -Tsvg -odb-hierarchy.svg db-hierarchy.gv
