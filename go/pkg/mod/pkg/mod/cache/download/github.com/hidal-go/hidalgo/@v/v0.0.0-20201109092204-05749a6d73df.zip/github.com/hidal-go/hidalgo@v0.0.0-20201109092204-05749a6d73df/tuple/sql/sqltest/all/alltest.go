package alltest

import (
	_ "github.com/hidal-go/hidalgo/tuple/sql/mysql/test"
	_ "github.com/hidal-go/hidalgo/tuple/sql/postgres/test"
)
