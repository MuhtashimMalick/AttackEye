package all

import (
	_ "github.com/hidal-go/hidalgo/tuple/sql/mysql"
	_ "github.com/hidal-go/hidalgo/tuple/sql/postgres"
)
