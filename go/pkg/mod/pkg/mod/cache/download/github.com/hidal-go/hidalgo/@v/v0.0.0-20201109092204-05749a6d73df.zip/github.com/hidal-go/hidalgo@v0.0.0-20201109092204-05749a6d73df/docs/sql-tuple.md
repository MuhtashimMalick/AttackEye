## SQL tuple store

SQL provides a natural way to store tuples indexed by a primary key.

**Supported backends:**

* [MySQL](https://www.mysql.com)
* [PostgreSQL](http://www.postgresql.org)