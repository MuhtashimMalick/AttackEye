package all

import (
	_ "github.com/hidal-go/hidalgo/legacy/nosql/couch"
	_ "github.com/hidal-go/hidalgo/legacy/nosql/elastic"
	_ "github.com/hidal-go/hidalgo/legacy/nosql/mongo"
)
