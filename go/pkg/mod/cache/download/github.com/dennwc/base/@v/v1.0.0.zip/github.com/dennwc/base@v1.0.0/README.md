# Common Go interfaces

This package provides a few common Go interfaces:

- Iterator
- Transaction (Tx)